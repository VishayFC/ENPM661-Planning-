# How to run the code


Recommended Python : Python 3.9.1


Recommended IDE : SPYDER 


Libraries Used : NUMPY


--To run each test case, simpy uncomment the respective line and uncomment the respective piece of code for writing the data into a text file


--Default setting is for TEST CASE 5

